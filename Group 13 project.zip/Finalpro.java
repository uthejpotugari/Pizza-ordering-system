
public class Finalpro {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
pizzasrore a=new pizzasrore();

Billing c=new Billing();
custo d=new custo();












System.out.println("Welcome!");
a.get_location();
astores b=new astores();
c.calc();
c.display();
d.getName();
d.getAddress();
d.getPhone_no();
d.feedback();

	}

}
